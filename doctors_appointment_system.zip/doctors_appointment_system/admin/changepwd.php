
<title>Doctor's appointment system</title>


<?php if(!isset($_SESSION))
{
	session_start();
}  
?>
			<div class="dashboard" style="background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;;color: #fff;padding: 5px;">Change Password</h3>
		<div class="formstyle" style="float: right;padding:20px;border: 1px solid lightgrey;margin-right:500px; margin-bottom:30px;background-color:#f3f3f8;color:#141313;">

					<form action="" method="post" class="text-left">
						
						<table width=250px>
						
						<tr>Old Password: </tr><br>
						<tr><input type="password" name="password" size=30 placeholder="Current password" required></tr></br></br>
					
						<tr>New Password: </tr><br>
						<tr><input type="password" name="newpassword" size=30  placeholder="New password" required></tr></br></br>
						
						<tr>Confirm Password: </tr><br>
						<tr><input type="password" name="confpassword" size=30 placeholder=" re-type password" required></tr></br></br>
						
						<tr><button name="submit" type="submit" class="badge badge-info">Update Password</tr>

						</table>
				
						<?php 
						$newpassword='';
						$confpassword='';
							
						include('db_connect.php');
						if(isset($_POST["submit"]))
						{
							$sql= "SELECT * FROM users WHERE doctor_id= '" . $_SESSION['login_doctor_id']."' AND password= '" . $_POST['password']."' and type=2";

							$query=mysqli_query($conn,$sql);
							$row=mysqli_num_rows($query);

							if($row > 0)
							{
								//check the new password
								if($newpassword==$confpassword)
								{
									$sql1="UPDATE users SET password='" . $_POST["newpassword"]  ."' WHERE doctor_id='" .$_SESSION['login_doctor_id'] ."'";
									mysqli_query($conn,$sql1);
									echo "<script>alert('Password Has been Updated');</script>";
								}
								else
								{
									echo "<script>alert('Password did not match');</script>";

								}
							}
							else
							{
								echo "<script>alert('Input Correct Password');</script>";
							}
						}
						?>
					</form> <br>&nbsp;&nbsp;&nbsp;
				</div>
			</div>

</body>
</html>
