<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<div class="container-fluid">
	<div class="row">
		<div class="card col-lg-12">
			<div class="card-body">
				<table class="table-striped table-bordered col-md-12">
			<thead>
				<tr>
					<th class="text-center">#</th>
					<th class="text-center">Username</th>
					<th class="text-center">feedback</th>
					<th class="text-center">action</th>
				</tr>
			</thead>
			<tbody>
				<?php
 					include 'db_connect.php';
 					$feedback = $conn->query("SELECT * FROM feedback order by email asc");
 					$i = 1;
 					while($row= $feedback->fetch_assoc()):
				 ?>
				 <tr>
				 	<td>
				 		<?php echo $i++ ?>
				 	</td>
				 	<td>
				 		<?php echo $row['email'] ?>
				 	</td>
				 	<td>
				 		<?php echo $row['feedback'] ?>
				 	</td>
				 	<td class="text-center">
				 		<center>
							<button class="btn btn-sm btn-danger delete_feedback" type="button" data-id="<?php echo $row['id'] ?>">Delete</button>
						</center>
				 	</td>
				 </tr>
				<?php endwhile; ?>
			</tbody>
			<?php
					
				while($row=mysqli_fetch_array($feedback))
				{
					echo "<tr>";
					echo "<td>".$row['id']."</td>";
					echo "<td>".$row['email']."</td>";
					echo "<td>".$row['feedback']."</td>";
					echo "</tr>";
				}
					
			?>
		</table>
			</div>
		</div>
	</div>

</div>
<script>
$('.delete_feedback').click(function(){
		_conf("Are you sure to delete this feedback?","delete_feedback",[$(this).attr('data-id')])
	})
	function delete_feedback($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_feedback',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
	
	
</script>
