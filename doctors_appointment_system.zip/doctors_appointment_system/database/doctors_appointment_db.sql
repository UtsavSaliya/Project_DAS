-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2023 at 09:49 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctors_appointment_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment_list`
--

CREATE TABLE `appointment_list` (
  `id` int(10) NOT NULL,
  `doctor_id` int(10) NOT NULL,
  `patient_id` int(10) NOT NULL,
  `schedule` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0= for verification, 1=confirmed,2= reschedule,3=done',
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment_list`
--

INSERT INTO `appointment_list` (`id`, `doctor_id`, `patient_id`, `schedule`, `status`, `date_created`) VALUES
(1, 7, 10, '2023-12-20 12:00:00', 0, '2023-12-12 14:06:13'),
(2, 2, 10, '2023-12-21 18:00:00', 0, '2023-12-12 14:06:46'),
(3, 3, 11, '2023-12-22 16:00:00', 0, '2023-12-12 14:08:56'),
(4, 8, 12, '2023-12-25 17:00:00', 0, '2023-12-12 14:11:43'),
(5, 6, 12, '2023-12-26 14:00:00', 0, '2023-12-12 14:12:06'),
(6, 5, 13, '2023-12-20 11:00:00', 0, '2023-12-12 14:13:41'),
(7, 1, 13, '2023-12-19 14:00:00', 0, '2023-12-12 14:14:17'),
(8, 4, 14, '2023-12-23 18:00:00', 0, '2023-12-12 14:16:46'),
(9, 8, 14, '2023-12-19 17:00:00', 0, '2023-12-12 14:17:12'),
(10, 7, 14, '2023-12-20 11:00:00', 0, '2023-12-12 14:17:35');

-- --------------------------------------------------------

--
-- Table structure for table `doctors_list`
--

CREATE TABLE `doctors_list` (
  `id` int(10) NOT NULL,
  `name` text NOT NULL,
  `name_pref` varchar(5) NOT NULL,
  `clinic_address` varchar(60) NOT NULL,
  `contact` varchar(14) NOT NULL,
  `email` varchar(30) NOT NULL,
  `specialty_ids` text NOT NULL,
  `img_path` varchar(90) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors_list`
--

INSERT INTO `doctors_list` (`id`, `name`, `name_pref`, `clinic_address`, `contact`, `email`, `specialty_ids`, `img_path`, `date_created`) VALUES
(1, 'DR. M K DAVE', 'M.D.', 'Nilam nagar, Ahmedabad', '+91 9878789855', 'yashpatel123@gmail.com', '[4]', '1702367700_mkdave.png', '2023-12-12 13:25:51'),
(2, 'DR. SEJAL PATEL', 'MBBS.', 'Sardarnagar gurukul, Bhavnagar', '+91 8200065192', 'sejalpatel123@gmail.com', '[1]', '1702367940_sejalpatel.png', '2023-12-12 13:29:04'),
(3, 'DR. NANDINI CHOPDA', 'M.D.', 'Silver stone, Rajkot', '+91 9966332541', 'nandinichopda123@gmail.com', '[5]', '1702368060_Nandini Chopda.jpg', '2023-12-12 13:31:05'),
(4, 'DR. PARITA MANIYA', ' ', 'Near kakariya lake, Ahmedabad', '+91 9925574014', 'paritamaniya123@gmail.com', '[3]', '1702368180_paritamaniya.png', '2023-12-12 13:33:38'),
(5, 'DR. AVANI TRIVEDI', 'MBBS.', 'Jwellers Circle, Anand', '+91 9824289592', 'avanitrivedi123@gmail.com', '[7]', '1702368360_Avani patel.jpg', '2023-12-12 13:36:03'),
(6, 'DR. B K SHAH', 'BHMS.', 'Yogi chowk, Surat', '+91 9878456525', 'bkshah123@gmail.com', '[6]', '1702368420_bkshah.jpg', '2023-12-12 13:37:44'),
(7, 'DR. YASH PATEL', 'BDS.', 'C G Road, Ahmedabad', '+91 9510651410', 'yashpatel123@gmail.com', '[2]', '1702368600_Yash patel.jpg', '2023-12-12 13:40:55'),
(8, 'DR. MITESH DAVRA', 'MB. ', 'Lila Circle, Baroda', '+91 7845123698', 'miteshdavra123@gmail.com', '[1]', '1702368780_Mitesh Davra.png', '2023-12-12 13:43:50');

-- --------------------------------------------------------

--
-- Table structure for table `doctors_schedule`
--

CREATE TABLE `doctors_schedule` (
  `id` int(10) NOT NULL,
  `doctor_id` int(10) NOT NULL,
  `day` varchar(20) NOT NULL,
  `time_from` time NOT NULL,
  `time_to` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors_schedule`
--

INSERT INTO `doctors_schedule` (`id`, `doctor_id`, `day`, `time_from`, `time_to`) VALUES
(1, 1, 'Monday', '10:00:00', '16:00:00'),
(2, 1, 'Tuesday', '10:00:00', '16:00:00'),
(3, 1, 'Wednesday', '10:00:00', '16:00:00'),
(4, 1, 'Thursday', '10:00:00', '16:00:00'),
(5, 2, 'Wednesday', '16:00:00', '20:00:00'),
(6, 2, 'Thursday', '16:00:00', '20:00:00'),
(7, 2, 'Friday', '16:00:00', '20:00:00'),
(8, 2, 'Saturday', '16:00:00', '20:00:00'),
(9, 3, 'Monday', '12:00:00', '17:00:00'),
(10, 3, 'Wednesday', '12:00:00', '17:00:00'),
(11, 3, 'Friday', '12:00:00', '17:00:00'),
(12, 4, 'Monday', '14:00:00', '18:00:00'),
(13, 4, 'Tuesday', '14:00:00', '18:00:00'),
(14, 4, 'Wednesday', '14:00:00', '18:00:00'),
(15, 4, 'Thursday', '14:00:00', '18:00:00'),
(16, 4, 'Friday', '14:00:00', '18:00:00'),
(17, 4, 'Saturday', '14:00:00', '18:00:00'),
(18, 5, 'Wednesday', '09:00:00', '12:00:00'),
(19, 5, 'Thursday', '09:00:00', '12:00:00'),
(20, 5, 'Friday', '09:00:00', '12:00:00'),
(21, 6, 'Monday', '11:00:00', '15:00:00'),
(22, 6, 'Tuesday', '11:00:00', '15:00:00'),
(23, 6, 'Thursday', '15:00:00', '20:00:00'),
(24, 6, 'Friday', '15:00:00', '20:00:00'),
(25, 7, 'Monday', '10:00:00', '18:00:00'),
(26, 7, 'Wednesday', '10:00:00', '18:00:00'),
(27, 7, 'Saturday', '10:00:00', '18:00:00'),
(28, 8, 'Monday', '13:00:00', '18:00:00'),
(29, 8, 'Tuesday', '13:00:00', '18:00:00'),
(30, 8, 'Wednesday', '13:00:00', '18:00:00'),
(31, 8, 'Thursday', '13:00:00', '18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `feedback` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medical_specialty`
--

CREATE TABLE `medical_specialty` (
  `id` int(10) NOT NULL,
  `name` text NOT NULL,
  `img_path` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medical_specialty`
--

INSERT INTO `medical_specialty` (`id`, `name`, `img_path`) VALUES
(1, 'Pediatrics', '1702366980_Pediatrics.png'),
(2, 'Dentist', '1702367100_Dentist.jpg'),
(3, 'Cardiology', '1702367160_Cardiology.png'),
(4, 'Orthopaedics', '1702367280_Orthopaedics.jpg'),
(5, 'Obstetrician/gynecologists', '1702367340_Obstetriciangynecologists.jpg'),
(6, 'Neurologists', '1702367400_Neurologists.jpg'),
(7, 'Skin Disease', '1702367460_Skin Disease.png'),
(8, 'Ophthalmology', '1702367520_Ophthalmology.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `cover_img` text NOT NULL,
  `about_content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `name`, `email`, `contact`, `cover_img`, `about_content`) VALUES
(1, 'Doctor’s Appointment System', 'info@sample.com', '+7678 8542 623', '1701100380_1615454520_ing.jpg', '&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;ABOUT US&lt;/span&gt;&lt;/b&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;background: transparent; position: relative; font-size: 14px;&quot;&gt;&lt;span style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;&lt;b style=&quot;margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; text-align: justify;&quot;&gt;Lorem Ipsum&lt;/b&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-weight: 400; text-align: justify;&quot;&gt;&amp;nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&amp;#x2019;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.&lt;/span&gt;&lt;br&gt;&lt;/span&gt;&lt;/b&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;background: transparent; position: relative; font-size: 14px;&quot;&gt;&lt;span style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-weight: 400; text-align: justify;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/b&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;background: transparent; position: relative; font-size: 14px;&quot;&gt;&lt;span style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;&lt;h2 style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;Where does it come from?&lt;/h2&gt;&lt;p style=&quot;text-align: center; margin-bottom: 15px; padding: 0px; color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-weight: 400;&quot;&gt;Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.&lt;/p&gt;&lt;/span&gt;&lt;/b&gt;&lt;/span&gt;&lt;/p&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `doctor_id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `address` varchar(60) NOT NULL,
  `contact` varchar(14) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(10) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 2 COMMENT '1=admin , 2 = doctor,3=patient'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `doctor_id`, `name`, `address`, `contact`, `username`, `password`, `type`) VALUES
(1, 0, 'Administrator', '', '', 'admin', 'admin123', 1),
(2, 1, 'DR.DR. M K DAVE, M.D.', 'Nilam nagar, Ahmedabad', '+91 9878789855', 'yashpatel123@gmail.com', 'yash123', 2),
(3, 2, 'DR.DR. SEJAL PATEL, MBBS.', 'Sardarnagar gurukul, Bhavnagar', '+91 8200065192', 'sejalpatel123@gmail.com', 'sejal123', 2),
(4, 3, 'DR.DR. NANDINI CHOPDA, M.D.', 'Silver stone, Rajkot', '+91 9966332541', 'nandinichopda123@gmail.com', 'nandini123', 2),
(5, 4, 'DR.DR. PARITA MANIYA,  ', 'Near kakariya lake, Ahmedabad', '+91 9925574014', 'paritamaniya123@gmail.com', 'parita123', 2),
(6, 5, 'DR.DR. AVANI TRIVEDI, MBBS.', 'Jwellers Circle, Anand', '+91 9824289592', 'avanitrivedi123@gmail.com', 'avani123', 2),
(7, 6, 'DR.DR. B K SHAH, BHMS.', 'Yogi chowk, Surat', '+91 9878456525', 'bkshah123@gmail.com', 'bkshah123', 2),
(8, 7, 'DR.DR. YASH PATEL, BDS.', 'C G Road, Ahmedabad', '+91 9510651410', 'yashpatel123@gmail.com', 'yash123', 2),
(9, 8, 'DR.DR. MITESH DAVRA, MB. ', 'Lila Circle, Baroda', '+91 7845123698', 'miteshdavra123@gmail.com', 'mitesh123', 2),
(10, 0, 'Nirav Nayani', 'Ambe chowk, Baroda', '+91 9874566547', 'niravnayani12@gmail.com', 'nirav12', 3),
(11, 0, 'Bhumi Saliya', 'Near avlone, Surat ', '+91 8200363645', 'bhumisaliya12@gmail.com', 'bhumi12', 3),
(12, 0, 'Akash Sonani', 'Sardarnagar society, Bhavnagar', '+91 7845548778', 'akashsonani12@gmail.com', 'akash12', 3),
(13, 0, 'Saloni Khunt', 'Near cineplex, Anand', '+91 9878987452', 'salonikhunt12@gmail.com', 'saloni12', 3),
(14, 0, 'Rutvik Beladiya', 'C-12 ganesh-raw-house, Baroda', '+91 8574123654', 'rutvikbeladiya12@gmail.com', 'rutvik12', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment_list`
--
ALTER TABLE `appointment_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors_list`
--
ALTER TABLE `doctors_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors_schedule`
--
ALTER TABLE `doctors_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medical_specialty`
--
ALTER TABLE `medical_specialty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment_list`
--
ALTER TABLE `appointment_list`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `doctors_list`
--
ALTER TABLE `doctors_list`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `doctors_schedule`
--
ALTER TABLE `doctors_schedule`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medical_specialty`
--
ALTER TABLE `medical_specialty`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
